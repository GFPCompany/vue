<script setup>

import EcosystemIcon from "@/components/icons/IconEcosystem.vue";
import ToolingIcon from "@/components/icons/IconTooling.vue";
import SupportIcon from "@/components/icons/IconSupport.vue";
import WelcomeItem from "@/components/WelcomeItem.vue";
import CommunityIcon from "@/components/icons/IconCommunity.vue";
import DocumentationIcon from "@/components/icons/IconDocumentation.vue";
var github = "https://github.com/GFPCompany";
</script>

<template>
  <div class="about">
    <div class="block-header">
      <h1 class="green">About GFP Blockchain</h1>
    </div>
    <div class="content">
      <WelcomeItem>
        <template #icon>
          <DocumentationIcon />
        </template>
        <template #heading>Documentation</template>

        GFPBlockain's
        <a href="#" target="_blank" rel="noopener">official documentation</a>
        provides you with all information you need to get started.
      </WelcomeItem>

      <WelcomeItem>
        <template #icon>
          <ToolingIcon />
        </template>
        <template #heading>Toolset</template>

        This project is served and bundled with
        <div class="c-list">
          <div class="c-list-item">
            <a href="https://yandex.ru/search/?text=ecdsa" target="_blank" rel="noopener">ECDSA</a>
          </div>
          <div class="c-list-item">
            <a href="https://yandex.ru/search/?text=sha256" target="_blank" rel="noopener">SHA256</a>
          </div>
          <div class="c-list-item">
            <a href="https://yandex.ru/search/?text=sha512" target="_blank" rel="noopener">SHA512</a>
          </div>
          <div class="c-list-item">
            <a href="https://yandex.ru/search/?text=ripemd" target="_blank" rel="noopener">RIPEMD</a>
          </div>
          <div class="c-list-item">
            <a href="https://yandex.ru/search/?text=python" target="_blank" rel="noopener">Python</a>
          </div>

        </div>

        More instructions are available in <code>README.md</code> at <a href="https://github.com/GFPCompany/GFPBlockchain" target="_blank" rel="noopener">GitHub Repo</a>.
      </WelcomeItem>

      <WelcomeItem>
        <template #icon>
          <EcosystemIcon />
        </template>
        <template #heading>Ecosystem</template>

        Get official tools and libraries for your own SoftWare:
        <a v-bind:href="github" target="_blank" rel="noopener">GFP ECDSA</a>,
        <a v-bind:href="github" target="_blank" rel="noopener">GFP Algo</a>,
        <a v-bind:href="github" target="_blank" rel="noopener">GFP NetLib</a>, and
        <a v-bind:href="github" target="_blank" rel="noopener">Premium GFP Dev Pack</a>
        <p>GFPBlockchain Net is is based on peer-to-peer nodes:</p>
        <table>
          <thead>
            <tr>
              <th>Type</th>
              <th>Features</th>
              <th>Requirements</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><a target="_blank" rel="noopener">FullNode</a></td>
              <td><span>Local copy</span></td>
              <td>VDS/VPS </td>
            </tr>
            <tr>
              <td></td>
              <td><span>Transactions validator</span></td>
              <td>4 Cores+ Xeon/Core</td>
            </tr>
            <tr>
              <td></td>
              <td><span>P2P network unit</span></td>
              <td>16GB+ RAM</td>
            </tr>
            <tr>
              <td></td>
              <td><span>Miner</span></td>
              <td>Nvidia 3060 or higher</td>
            </tr>
            <tr>
              <td><a target="_blank" rel="noopener">LightNode</a></td>
              <td><span>Transactions validator</span></td>
              <td>Mobile/Tablet based on ARM Core</td>
            </tr>
            <tr>
              <td></td>
              <td><span>P2P network unit</span></td>
              <td>4GB+ RAM</td>
            </tr>
          </tbody>
        </table>
      </WelcomeItem>

      <WelcomeItem>
        <template #icon>
          <CommunityIcon />
        </template>
        <template #heading>Community</template>

        Got stuck? Ask your question on
        <a target="_blank" rel="noopener">GiHub</a>, our official
        Discord server, or
        <a href="https://stackoverflow.com/" target="_blank" rel="noopener"
        >StackOverflow</a
        >.
      </WelcomeItem>

      <WelcomeItem>
        <template #icon>
          <SupportIcon />
        </template>
        <template #heading>Support GFP</template>

        As an independent project, GFPBlockchain relies on community backing for its sustainability. You can help
        us by
        <a target="_blank" rel="noopener">becoming a sponsor</a>.
      </WelcomeItem>
    </div>
  </div>
</template>

<style scoped>
.about {
  padding: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.green {
  text-decoration: none;
  color: hsla(160, 100%, 37%, 1);
  transition: 0.4s;
  padding: 3px;
}
table {
  user-select: none;
  border-collapse: collapse;
  border: 1px solid #00BD7EFF;

  font-family: sans-serif;
  font-size: 0.8rem;
  letter-spacing: 1px;
}
th,
td {
  border: 1px solid rgb(124, 56, 56);
  padding: 8px 10px;

}
td span{
  background-color: hsla(160, 13%, 50%, 0.2);
  padding: 4px 5px;
}
</style>