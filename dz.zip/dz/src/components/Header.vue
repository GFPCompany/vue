<script setup>
import { createMemoryHistory, createRouter } from 'vue-router';
</script>

<template>
<div class="header">
  <div class="logo">

  </div>
  <div class="links-container">
    <a href="/" class="link">Home</a>
    <a href="/hash" class="link">Hash</a>
    <a href="/transactions" class="link">Transactions</a>
    <a href="/network" class="link">Network</a>
  </div>
</div>
</template>

<style scoped>
@font-face {
  font-family: Poppins;
  src: url("../assets/fonts/Poppins-Light.ttf") format("truetype");
}
.header {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 10px;
}
.header .links-container .link{
  margin-left: 15px;
  text-decoration: none;
  padding: 10px 10px;
  font-weight: bold;
  font-size: 12pt;
  font-family: Poppins,serif;
}
.header .link:hover{
  background-color: #f5f5f5;
  border-radius: 5px;
  background-color: hsla(160, 100%, 37%, 0.2);
}
</style>