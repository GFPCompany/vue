<script setup>

import Header from "../../components/Header.vue";
import Algo_SHA256 from "@/pages/Home/components/Algo_SHA256.vue";
</script>

<template>
  <Header/>
  <Algo_SHA256/>
<RouterView/>
</template>

<style scoped>

</style>