<script setup>

import About from "@/components/About.vue";
import Header from "@/components/Header.vue";
</script>

<template>
  <Header/>
  <About/>
</template>

<style scoped>

</style>