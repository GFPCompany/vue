<script setup>
import { sha256 } from '@noble/hashes/sha256';
import {sha512} from "@noble/hashes/sha512";
import {ripemd160} from "@noble/hashes/ripemd160";
import "./algo-sha256.css"
function sha256_hash(sha256_input) {
  var res = ""
  var hash = sha256(sha256_input)
  for(var i in hash){
    res += hash[i].toString(16).toUpperCase()
  }
  return res;
}
function sha512_hash(sha256_input) {
  var res = ""
  var hash = sha512(sha256_input)
  for(var i in hash){
    res += hash[i].toString(16).toUpperCase()
  }
  return res;
}
function ripemd_hash(sha256_input) {
  var res = ""
  var hash = ripemd160(sha256_input)
  for(var i in hash){
    res += hash[i].toString(16).toUpperCase()
  }
  return res;
}
</script>
<template>
<div class="algo">
  <div class="outputs">
    <div class="out">
      <div class="name">
        SHA256
      </div>
      <div class="result">
        <span v-bind:style="{fontSize:result_style+'px'}" >{{sha256_hash(sha256_input)}}</span>
      </div>
    </div>
    <div class="out">
      <div class="name">
        SHA512
      </div>
      <div class="result">
        <span v-bind:style="{fontSize:result_style+'px'}">{{sha512_hash(sha256_input)}}</span>
      </div>
    </div>
    <div class="out">
      <div class="name">
        RIPEMD
      </div>
      <div class="result">
        <span v-bind:style="{fontSize:result_style+'px'}">{{ripemd_hash(sha256_input)}}</span>
      </div>
    </div>

  </div>
  <div class="input-container">
    <input v-model="sha256_input" placeholder="Enter text" >
  </div>
  <div class="input-container">
    <input v-model="result_style" placeholder="Enter result font size" >
  </div>
</div>
</template>

<style scoped>

</style>
<script>
export default {
  name: 'algo-sha256',
  data() {
    return {
      sha256_input: '',result_style:"14"
    };
  },
}
</script>