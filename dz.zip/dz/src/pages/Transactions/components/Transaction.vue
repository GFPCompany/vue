<script setup>

</script>

<template>
<div class="transaction-card">
  <div class="txid">
    <div class="lbl">
      TXID:
    </div>
    <div class="val">
      {{ txid }}
    </div>
  </div>
  <div class="amount">
    <div class="lbl">
      Amount:
    </div>
    <div class="val">
      {{ amount }}
    </div>
  </div>
</div>
</template>

<style scoped>
@font-face {
  font-family: Poppins;
  src: url("../../../assets/fonts/Poppins-Light.ttf") format("truetype");
}
.transaction-card{
  margin: 20px;
  display: block;
  border-radius: 10px;
  padding: 10px 40px;

  background: rgb(0,214,59);
  background: linear-gradient(90deg, rgba(0,214,59,0.13068977591036413) 0%, rgba(218,254,205,1) 8%, rgba(30,227,140,1) 100%);
}
.transaction-card .txid, .transaction-card .amount{
  display: block;
}
.transaction-card .txid .lbl, .transaction-card .amount .lbl{
  display: inline-block;
  font-family: Poppins;
  font-style: normal;
  font-weight: 500;
  font-size: 18px;
  line-height: 27px;
  color: #000000;
}
.transaction-card .txid .val, .transaction-card .amount .val{
  display: inline-block;
  font-family: Poppins;
  font-style: normal;
  font-weight: 500;
  font-size: 15px;
  line-height: 27px;
  color: #000000;
}
</style>
<script>
export default {
  name: 'Transaction',
  data() {
    return {
      sha256_input: '',result_style:"14"
    };
  },
  props: {
    txid:String,
    amount:String
  },
}
</script>