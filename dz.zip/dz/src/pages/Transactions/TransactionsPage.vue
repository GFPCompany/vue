<script setup>

import About from "@/components/About.vue";
import Header from "../../components/Header.vue";
import Transaction from "@/pages/Transactions/components/Transaction.vue";
import {sha256} from "@noble/hashes/sha256";
import {randomBytes} from "@noble/hashes/utils";
function sha256_hash(sha256_input) {
  var res = ""
  var hash = sha256(sha256_input)
  for(var i in hash){
    res += hash[i].toString(16).toUpperCase()
  }
  return res;
}
var data = [
]
for(var i=0; i<10; i++){
  data.push({
    txid: "0x"+sha256_hash(randomBytes(256).toString()),
    amount:( parseInt((randomBytes(5)).toString(),10)/1000).toString()
  })
}
</script>

<template>
  <Header/>
  <span v-for="i in data">
    <Transaction :txid="i.txid" :amount="i.amount"/>
  </span>

</template>

<style scoped>

</style>
