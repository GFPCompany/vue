import './assets/main.css'

import { createApp } from 'vue'
import App from './App.vue'
import {createMemoryHistory, createRouter} from "vue-router";
import About from "@/components/About.vue";
import router from "@/index.js";

const app = createApp(App)
    .use(router)
    .mount('#app')