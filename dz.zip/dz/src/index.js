import { createWebHistory, createRouter } from "vue-router";
import About from "@/components/About.vue";
import App from "@/App.vue";
import HashPage from "@/pages/Hash/HashPage.vue";
import HomePage from "@/pages/Home/HomePage.vue";
import TransactionsPage from "@/pages/Transactions/TransactionsPage.vue";
const routes = [
    {
        path: "/",
        name: "Home",
        component: HomePage,
    },
    {
        path: "/hash",
        name: "Hash",
        component: HashPage,
    },
    {
        path: "/transactions",
        name: "Transactions",
        component: TransactionsPage,
    },
    {
        path: "/:pathMatch(.*)*",
        name:"404",
        component: HomePage,
    }
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

export default router;